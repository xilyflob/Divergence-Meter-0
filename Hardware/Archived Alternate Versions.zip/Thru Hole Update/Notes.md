# Description
These files are a somewhat minor evolution of Tom Titor's original boards. It keeps with the majority through hole components like the original. But a bunch are replaced for improved alternates or removed since from what I could see no one ever used them or they served no purpose.

* All the changes that were done were to the logic/main board. There just isn't a whole ton of room for tweaks on the display board.
* I'll admit that I spent a lot less time working on this one than the other versions, please do checks to make sure that everything is in place correctly.

